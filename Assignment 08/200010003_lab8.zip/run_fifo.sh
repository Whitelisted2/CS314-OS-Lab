#!/bin/bash

g++ fifo.cpp -o fifo.out
./fifo.out $1 $2 $3 $4
