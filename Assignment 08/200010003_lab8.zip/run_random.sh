#!/bin/bash

g++ random.cpp -o random.out
./random.out $1 $2 $3 $4
