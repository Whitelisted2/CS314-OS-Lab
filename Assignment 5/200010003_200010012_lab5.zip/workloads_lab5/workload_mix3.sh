#!/bin/bash

./arithoh.sh &
./fstime.sh &
./syscall.sh &
./arithoh.sh &
./arithoh.sh &
wait