### Instructions

run using `bash run.sh <input-file>`

or , use `bash run.sh <input-file> <output-file>`

Errors are handled. Make sure the input file path is provided correctly.