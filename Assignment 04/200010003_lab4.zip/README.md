## Assignment 4 Submission (Roll: 200010003)
<hr>

#### Please follow these instructions.

- To run SJF, run the following: \
bash run.sh \<path-to-input-file\> [\<path-to-output-file>]

Example1: bash run.sh inputs/process1.dat \
Example2: bash run.sh inputs/process1.dat output.txt

- Running RR would be same as above, but with run2.sh instead. (Current form of the code has some issues ... )